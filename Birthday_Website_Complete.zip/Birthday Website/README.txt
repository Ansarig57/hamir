BIRTHDAY WEBSITE

1. Open index.html in a browser.
2. Edit these lines near the top of the JavaScript:
   const NAME = "YOUR NAME";
   const PIN = "1234";

3. Put your three images in this folder with EXACT names:
   PNG 1.png
   PNG 2.png
   PNG 3.png

4. Put your music file in this folder and name it:
   birthday.mp3

5. Open index.html.

The PIN is a front-end surprise lock, not real security.
